
Explanation:

Install dependencies:
npm install express socket.io

Create server:
Sets up an Express server and creates an HTTP server on top of it.
Initializes Socket.IO on the HTTP server.
Handle connection events:
Logs connection events to the console.
When a user connects, it emits a 'join' message to all connected clients.
When a user sends a message, it emits a 'message' event to all clients.
Emits a 'disconnect' message when a user leaves the chat.

Start the server:
Starts the server on port 3000.

3. Run the Server
Open your terminal and navigate to the directory where you saved the file.
Run the server using node server.js.
4. Modify HTML Client

Replace ws://${serverIP} in the HTML with the actual IP address or domain of your server (e.g., ws://localhost:3000).

5.Configure the client
Open Simple-ChatApp.html in a browser.
Put in the IP address and port of the server into the client. Example: Server IP:<IP Address>:<Port>
Put in your username. (This does not have to be your real name)
Press connect.

6. Send a message
Type in your message and press send.
The message will now show to everybody else in using the same server.
