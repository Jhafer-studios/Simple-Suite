const express = require('express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

io.on('connection', (socket) => {
  console.log('A user connected');

  socket.on('join', (username) => {
    socket.username = username;
    io.emit('message', { type: 'system', message: `${username} has joined the chat.` }); 
  });

  socket.on('message', (data) => {
    io.emit('message', { type: 'message', username: data.username, message: data.message });
  });

  socket.on('disconnect', () => {
    io.emit('message', { type: 'system', message: `${socket.username} has left the chat.` });
  });
});

server.listen(3000, () => {
  console.log('Server listening on port 3000');
});