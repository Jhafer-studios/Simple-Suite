 Prerequisites:
-Node.js and npm and ws: Installed on server computer.
-Internet: On all computers.
-An web browser: Installed on both computers.

 How to set up the chat client:
1.Find the server's IP address:
-On the computer running the server, determine its IP address. You can usually find this in the network settings.

2.Run the server:
-Execute node server.js in the terminal on the server machine.

3.Run the client:
-Open Simple-ChatClient.html in a web browser on both computers.
-In the server-address input field, enter the IP address of the server machine followed by the port (e.g., ws://192.168.1.100:8080). (The default port is 8080)
-Click the "Connect" button on both clients.
-Start chatting!

