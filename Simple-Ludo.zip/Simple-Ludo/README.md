<h1><strong>Ludo King</strong></h1>
Ludo King is a Web based game made completely using HTML, CSS and Javascript. In this game there are total 4 player and each one has 4 pieces and each one has to roll the dice and whatever points he/she got has to move their piece on the board, at the end each piece ends up returning to the home at the center of the board, whoever made all his pieces to the home first got First postion and so one.

<h3>Rules</h3>
<ul>
  <li>Whenever a player gets 6 points after rolling the diece he'll get and other diece roll</li> 
  <li>A player will only be able to move his piece when he got 6 and ulocks his piece.</li>
  <li>Whenever a player ends his move over the piece the piece of someother player that piece of other player will return to its initial postion and first player will     and extra diece roll</li>
  <li>When ever a player make home he'll be given an extra diece roll</li>
